An open-source typeface based on early 20th century American geometric sans serifs. Built out of necessity. Originally designed by Matt Bailey.

In 2020, Mirko Velimirovic converted Spartan MB to a variable font

To contribute to development please see [github.com/bghryct/Spartan-MB](https://github.com/bghryct/Spartan-MB)